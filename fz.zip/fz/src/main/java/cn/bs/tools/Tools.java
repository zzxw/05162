package cn.bs.tools;

public class Tools {
	public static boolean isEmpty(String string) {
		return (string == null || "".equals(string.trim()));
	}
}
